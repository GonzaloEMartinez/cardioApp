
let calculo = document.getElementById("botonCalcular")
    calculo.addEventListener("click", calculoImc )
    function calculoImc(){
    let altura = document.getElementById("altura").value;
    let peso = document.getElementById("peso").value;
    let imc = (peso) / (altura * altura)
    if(imc < 18.5){
        let contenedor1 = document.createElement("div")
        contenedor1.innerHTML = "Peso Inferior al Normal"
        document.body.appendChild(contenedor1)
    } else if ((imc > 18.5) && (imc < 24.9)){
        let contenedor2 = document.createElement("div")
        contenedor2.innerHTML = "Peso Normal"
        document.body.appendChild(contenedor2)
    } else if ((imc > 25) && (imc < 29.9)){
        let contenedor3 = document.createElement("div")
        contenedor3.innerHTML = "Peso Superior al Normal"
        document.body.appendChild(contenedor3)
    } else if (imc > 30) {
        let contenedor4 = document.createElement("div")
        contenedor4.innerHTML = "Obesidad"
        document.body.appendChild(contenedor4)
    }

    }

    $.getJSON("https://raw.githubusercontent.com/GonzaloEMartinez/testApi/main/data.json", function (data, estado) {
            ;
            for(let medicos of data){
                $("#plantilla").hide();
                $("#botonPlantilla").on("click", function(){$("#plantilla").toggle()})
                $("#plantilla").append(crearComponente(medicos))
            }
        }
    );
    
    function crearComponente(medicos){
        return `<div id=divPlantilla>
                <img id="imagen" src="${medicos.foto}">
                <p class="pPlantilla">${medicos.nombre}</p>
                <p class="pPlantilla">${medicos.especialidad}</p>
                </div>
                `;
      }

    $("#botonNoct").on("click", function(){
        $("body").toggleClass("nocturno");
    })
    