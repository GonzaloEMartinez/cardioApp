class Paciente {
    constructor(nombre, edad, dni){
        this.validarNombre(nombre);
        this.edad = edad;
        this.dni = dni;
    }

    validarNombre(nombre){
        if (nombre.length > 2){
            this.nombre = nombre.toUpperCase()
        } else if ((nombre.length =="") || (nombre.length <=2)){
            alert("Ingrese el nombre correctamente");
            this.nombre = "Error"
        }
    }
}

$("#botonPrincipal").on("click", function(){
    let nombre = document.getElementById("nombre").value
    let edad = document.getElementById ("edad").value
    let dni = document.getElementById("dni").value
    const paciente = new Paciente ((nombre), (edad), (dni));
    $("body").append(   `<h2> Nombre del paciente: ${paciente.nombre}</h2>
                        <h2> Edad: ${paciente.edad}</h2>
                        <h2> DNI: ${paciente.dni}</h2> `)
    localStorage.setItem("Paciente" , nombre)
    })
   
